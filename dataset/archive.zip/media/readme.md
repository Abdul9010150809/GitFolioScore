# Media

## Logo

- Primary color: `#fc60a8`
- Secondary color: `#494368`
- Font: [`Orbitron`](https://fonts.google.com/specimen/Orbitron)

You are free to use and modify the logo for your Awesome list or other usage.
